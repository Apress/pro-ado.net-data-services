Pro ADO.NET Data Services : Working With RESTful Data Example Code
------------------------------------------------------------------

This zip file contains the source code for the exercises in the book.

The code is organized into a folder for each chapter, as described below:

Chapter02 - Addressing RESTful ADO.NET Data Services
Chapter04 - Exposing Existing WCF SOAP Services and .NET APIs Through ADO.NET Data Services
Chapter05 - ASP.NET and AJAX Solutions
Chapter06 - Mashing Up Data Services
Chapter07 - Silverlight 2.0 Solutions
Chapter08 - Using ADO.NET Data Services with BizTalk

Using the solution code
-----------------------

Each chapter folder contains one or more exercises, each of which is seperated into seperate folders and Visual Studio Solutions pere exercise. Each solution contains the finished code for an exercise.

To open a solution you will need fullfil the system prerequisites as described in chapter 2. Additionally if you are using BizTalk or Silverlight, you will need to follow the system prerequisites described in the respective chapters. Opening the solution file for any given exercise will open the complete solution in Visual Studio.

SQL Server Express Databases
----------------------------

Exercises in chapters 2, 4, 5 and 7 contain SQL Server Express databases. To access these databases via SQL Server Management Studio, navigate to SQL Server explorer, Right click Databases -> attach -> Navigate to DatabaseName.mdf -> Grant DBO Security access to local administrator.

IMPORTANT NOTE:

You must review and the database connection string for each database connection to run the solutions successfully. To do this review the <connectionString /> element in the each solution's XML web.config / app.config files to point the connection string to the correct part of your local file system where the exercise's database.mdf file is located. Check that you can access the databases via Visual Studio Server Explorer using the connection string you have in your config files.

Visual Studio Web Development Server
------------------------------------
For convenience, it is recommended to run all web site / web service code locally using the built in Web Development Server. This server runs a port that Visual Studio specifies. On any client code that consumes a web service, ensure that the code is calling the service on the correct URI and change the port if necessary.