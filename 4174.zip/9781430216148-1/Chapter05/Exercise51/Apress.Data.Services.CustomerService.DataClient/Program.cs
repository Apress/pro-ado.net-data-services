﻿using System;
using System.Linq;
using System.Data.Services.Client;
using System.Text;
using Apress.Data.Services.CustomerService.DataClient.CustomerModel;

namespace Apress.Data.Services.CustomerService.DataClient
{
    class Program
    {
        static void Main(string[] args)
        {
            int id = 1;
            string lastname = "Smith";

            CustomerEntities dataService = new CustomerEntities(new Uri("http://localhost:1478/Apress.Data.Services.CustomerService.Host/CustomerDataService.svc"));

            Console.WriteLine("Call to get customer by id");

            Customer customer = (from c in dataService.Customers.Expand("Salutation").Expand("Gender")
                             where c.CustomerId == id
                             select c).FirstOrDefault();

            Console.WriteLine(string.Format("Details for customer id: {0}", id));

            if (customer != null)
            {
                Console.WriteLine(string.Format("Name: {0} {1} {2}, Date of Birth: {3}, Gender: {4}", customer.Salutation.SalutationDescription, customer.FirstName, customer.LastName, customer.DateOfBirth, customer.Gender.GenderName));
            }

            Console.WriteLine();

            Console.WriteLine("Call to get customers by lastname");

            var customers = from c in dataService.Customers.Expand("Salutation").Expand("Gender")
                            where c.LastName == lastname
                            select c;

            foreach (Customer c in customers)
            {
                Console.WriteLine(string.Format("Details for customer id: {0}", c.CustomerId));
                Console.WriteLine(string.Format("Name: {0} {1} {2}, Date of Birth: {3}, Gender: {4}", c.Salutation.SalutationDescription, c.FirstName, c.LastName, c.DateOfBirth, c.Gender.GenderName));
            }

            Gender gender = (from g in dataService.Genders
                             where g.GenderId == "M"
                             select g).FirstOrDefault();

            Salutation salutation = (from s in dataService.Salutations
                                     where s.SalutationId == 1
                                     select s).FirstOrDefault();

            Customer newCustomer = new Customer
            {
                FirstName = "Jimmy",
                LastName = "Brown",
                DateOfBirth = new DateTime(1955, 10, 30),
                Gender = gender,
                Salutation = salutation
            };

            dataService.AddToCustomers(newCustomer);

            dataService.SetLink(newCustomer, "Gender", gender);
            dataService.SetLink(newCustomer, "Salutation", salutation);


            try 
	        {	        
		        DataServiceResponse response = dataService.SaveChanges();
                Console.WriteLine(string.Format("New customer with id {0} created", newCustomer.CustomerId));
	        }
	        catch (DataServiceRequestException ex)
	        {
                Console.WriteLine(string.Format("SaveChanges failed with the following error {0}", ex.Response.BatchHeaders.FirstOrDefault().Value));
	        }
        }
    }
}
