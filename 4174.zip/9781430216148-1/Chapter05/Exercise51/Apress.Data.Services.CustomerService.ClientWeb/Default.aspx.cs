﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Services.Client;
using CustomerModel;

public partial class _Default : System.Web.UI.Page 
{
    // The following line of code points the data services proxy to the root data service URI.
    // You may need to change the URI port number (1478) to the port your data service is running on.
    private CustomerEntities entities = new CustomerEntities(new Uri("http://localhost:1478/Apress.Data.Services.CustomerService.Host/CustomerDataService.svc"));
    private List<Customer> customers;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void SearchButton_Click(object sender, EventArgs e)
    {
        BindData();
    }

    private void BindData()
    {
        // set the data source to the customers property and bind the grid view to it
        CustomersGridView.DataSource = Customers;
        CustomersGridView.DataBind();
    }

    public List<Customer> Customers 
    {
        get
        {
            // only populate this property from the data service once in the life cycle of the page
            if (customers != null)
            {
                return customers;
            }

            if (!string.IsNullOrEmpty(LastNameTextBox.Text))
            {
                // retrieve the collection of customers complete with Gender and Salutation reference properties populated
                customers = (from c in entities.Customers.Expand("Gender").Expand("Salutation")
                             where c.LastName.Contains(LastNameTextBox.Text)
                             select c).ToList();
            }

            return customers;
        }
    }

    protected void CustomersGridView_RowEditing(object sender, GridViewEditEventArgs e)
    {
        CustomersGridView.EditIndex = e.NewEditIndex;
        BindData();
    }

    protected void CustomersGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        // get a reference to the edited row in the grid view
        GridViewRow row = CustomersGridView.Rows[CustomersGridView.EditIndex];

        if (row != null && row.RowType == DataControlRowType.DataRow)
        {
            // get the customerId for the edited row out of the data keys collection
            int customerId = int.Parse(CustomersGridView.DataKeys[row.DataItemIndex].Value.ToString());

            // obtain references to edit template controls using find control
            TextBox firstNameTextBox = row.FindControl("FirstNameTextBox") as TextBox;
            TextBox lastNameTextBox = row.FindControl("LastNameTextBox") as TextBox;
            Calendar dateOfBirthCalendar = row.FindControl("DateOfBirthCalendar") as Calendar;

            if (firstNameTextBox != null && lastNameTextBox != null && dateOfBirthCalendar != null)
            {
                // get the customer record being edited from the data service by its customer id
                Customer customer = (from c in entities.Customers.Expand("Gender").Expand("Salutation")
                                     where c.CustomerId == customerId
                                     select c).FirstOrDefault();

                // update the properties locally using tracked changes
                customer.FirstName = firstNameTextBox.Text;
                customer.LastName = lastNameTextBox.Text;
                customer.DateOfBirth = dateOfBirthCalendar.SelectedDate;

                entities.UpdateObject(customer);

                try
                {
                    // save the tracked changes back to the data service
                    DataServiceResponse response = entities.SaveChanges();

                    // switch the grid view out of edit mode and rebind the data.
                    CustomersGridView.EditIndex = -1;
                    BindData();
                }
                catch (DataServiceRequestException ex)
                {
                   ErrorLabel.Text = string.Format("Updating record failed with the following error {0}", ex.Message);
                }
            }
        }
    }

    protected void CustomersGridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        CustomersGridView.EditIndex = -1;
        BindData();
    }
}
