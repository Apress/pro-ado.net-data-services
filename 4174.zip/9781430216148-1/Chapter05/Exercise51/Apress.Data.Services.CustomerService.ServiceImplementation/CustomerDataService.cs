﻿using System;
using System.Collections.Generic;
using System.Data.Services;
using System.Linq;
using System.ServiceModel.Web;

namespace Apress.Data.Services.CustomerService.ServiceImplementation
{
    /// <summary>
    /// The customer data service implementation.
    /// </summary>
    public class CustomerDataService : DataService<CustomerEntities>
    {
        // This method is called only once to initialize service-wide policies.
        public static void InitializeService(IDataServiceConfiguration config)
        {
            config.SetEntitySetAccessRule("*", EntitySetRights.All);
            config.SetServiceOperationAccessRule("*", ServiceOperationRights.All);
        }

        /// <summary>
        /// Called when [customers change].
        /// </summary>
        /// <param name="c">The c.</param>
        /// <param name="operations">The operations.</param>
        [ChangeInterceptor("Customers")]
        public void OnCustomersChange(Customer c, UpdateOperations operations)
        {
            if (!IsPersistValid(c))
            {
                string message = "Customer entity is not valid. Change operation failed";
                throw new DataServiceException(400, message);
            }
        }

        /// <summary>
        /// Determines whether [is persist valid] [the specified customer].
        /// </summary>
        /// <param name="customer">The customer.</param>
        /// <returns>
        /// 	<c>true</c> if [is persist valid] [the specified customer]; otherwise, <c>false</c>.
        /// </returns>
        private bool IsPersistValid(Customer customer)
        {
            if (customer.CustomerId < 0)
            {
                return false;
            }

            if (customer.CustomerId < 1)
            {
                if (customer.Gender == null)
                {
                    return false;
                }

                if (customer.Salutation == null)
                {
                    return false;
                }

                if (string.IsNullOrEmpty(customer.Gender.GenderId) || (customer.Gender.GenderId != "M" && customer.Gender.GenderId != "F"))
                {
                    return false;
                }

                if (customer.Salutation.SalutationId < 1 || customer.Salutation.SalutationId > 10)
                {
                    return false;
                }
            }

            if (string.IsNullOrEmpty(customer.FirstName))
            {
                return false;
            }

            if (string.IsNullOrEmpty(customer.LastName))
            {
                return false;
            }

            if (customer.DateOfBirth == DateTime.MinValue)
            {
                return false;
            }

            return true;
        }
    }
}
