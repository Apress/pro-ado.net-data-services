﻿using System.Data.Services.Common;

namespace Apress.Data.Services.CustomerService.Data.Linq
{
    [DataServiceKey("CustomerId")]
    public partial class Customer
    {
    }

    [DataServiceKey("GenderId")]
    public partial class Gender
    {
    }

    [DataServiceKey("SalutationId")]
    public partial class Salutation
    {
    }
}
