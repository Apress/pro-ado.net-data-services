﻿using System;
using System.Collections.Generic;
using System.Data.Services;
using System.Linq;
using System.ServiceModel.Web;
using Apress.Data.Services.CustomerService.Data.Linq;

namespace Apress.Data.Services.CustomerService.ServiceImplementation
{
    /// <summary>
    /// The customer data service implementation.
    /// </summary>
    public class CustomerDataService : DataService<CustomerDatabaseDataContext>
    {
        // This method is called only once to initialize service-wide policies.
        public static void InitializeService(IDataServiceConfiguration config)
        {
            config.SetEntitySetAccessRule("*", EntitySetRights.All);
            config.SetServiceOperationAccessRule("*", ServiceOperationRights.All);
        }



        // Query interceptors, change interceptors and service operations go here
    }
}
