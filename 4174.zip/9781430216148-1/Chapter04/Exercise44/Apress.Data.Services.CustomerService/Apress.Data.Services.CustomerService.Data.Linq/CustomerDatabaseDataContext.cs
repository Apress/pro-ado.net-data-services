﻿using System.Data.Services;
using System.Data.Services.Common;
using System;
using System.Reflection;
using System.Linq;
using System.Data.Linq;

namespace Apress.Data.Services.CustomerService.Data.Linq
{
    [DataServiceKey("CustomerId")]
    public partial class Customer
    {
    }

    [DataServiceKey("GenderId")]
    public partial class Gender
    {
    }

    [DataServiceKey("SalutationId")]
    public partial class Salutation
    {
    }

    public partial class CustomerDatabaseDataContext : IUpdatable
    {
        #region IUpdatable Members

        public void AddReferenceToCollection(object targetResource, string propertyName, object resourceToBeAdded)
        {
            Type t = targetResource.GetType();

            PropertyInfo collectionProperty = GetPropertyInfoForType(t, propertyName, false);

            object collection = collectionProperty.GetValue(targetResource, null);

            collection.GetType().InvokeMember("Add",
              BindingFlags.Public | BindingFlags.Instance | BindingFlags.InvokeMethod,
              null, collection, new object[] { resourceToBeAdded });
        }

        public void ClearChanges()
        {
            MethodInfo mi = this.GetType().GetMethod("ClearCache", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.InvokeMethod);

            mi.Invoke(this, null);
        }

        public object CreateResource(string containerName, string fullTypeName)
        {
            Type t = Type.GetType(fullTypeName);

            ITable table = GetTableForType(t);

            object value = Construct(t);

            table.InsertOnSubmit(value);

            return (value);
        }

        public void DeleteResource(object targetResource)
        {
            ITable table = this.GetTable(targetResource.GetType());

            if (table == null)
            {
                throw new DataServiceException("Failed to locate table for resource");
            }
            table.DeleteOnSubmit(targetResource);
        }

        public object GetResource(IQueryable query, string fullTypeName)
        {
            object result = null;

            foreach (object item in query)
            {
                if (result != null)
                {
                    throw new DataServiceException("A single resource is expected");
                }
                result = item;
            }
            if (result == null)
            {
                throw new DataServiceException(404, "Resource not found");
            }
            if (fullTypeName != null)
            {
                if (result.GetType().FullName != fullTypeName)
                {
                    throw new DataServiceException("Resource type mismatch");
                }
            }
            return (result);
        }

        public object GetValue(object targetResource, string propertyName)
        {
            Type t = targetResource.GetType();

            PropertyInfo pi = GetPropertyInfoForType(t, propertyName, false);

            object value = null;

            try
            {
                value = pi.GetValue(targetResource, null);
            }
            catch (Exception ex)
            {
                throw new DataServiceException(string.Format(
                  "Failed getting property {0} value", propertyName), ex);
            }
            return (value);
        }

        public void RemoveReferenceFromCollection(object targetResource, string propertyName,
          object resourceToBeRemoved)
        {
            Type t = targetResource.GetType();

            PropertyInfo collectionProperty = GetPropertyInfoForType(t, propertyName, false);

            object collection = collectionProperty.GetValue(targetResource, null);

            collection.GetType().InvokeMember("Remove",
              BindingFlags.Public | BindingFlags.Instance | BindingFlags.InvokeMethod,
              null, collection, new object[] { resourceToBeRemoved });
        }

        public object ResetResource(object resource)
        {
            // Only required for replace semantics
            throw new NotImplementedException();
        }

        public object ResolveResource(object resource)
        {
            return (resource);
        }

        public void SaveChanges()
        {
            base.SubmitChanges();
        }

        public void SetReference(object targetResource, string propertyName, object propertyValue)
        {
            this.SetValue(targetResource, propertyName, propertyValue);
        }

        public void SetValue(object targetResource, string propertyName, object propertyValue)
        {
            Type t = targetResource.GetType();

            PropertyInfo pi = GetPropertyInfoForType(t, propertyName, true);

            try
            {
                pi.SetValue(targetResource, propertyValue, null);
            }
            catch (Exception ex)
            {
                throw new DataServiceException(
                  string.Format("Error setting property {0} to {1}", propertyName, propertyValue),
                  ex);
            }
        }

        private PropertyInfo GetPropertyInfoForType(Type t, string propertyName, bool setter)
        {
            PropertyInfo pi = null;

            try
            {
                BindingFlags flags = BindingFlags.Public | BindingFlags.Instance;
                flags |= setter ? BindingFlags.SetProperty : BindingFlags.GetProperty;

                pi = t.GetProperty(propertyName, flags);

                if (pi == null)
                {
                    throw new DataServiceException(string.Format("Failed to find property {0} on type {1}",
                      propertyName, t.Name));
                }
            }
            catch (Exception exception)
            {
                throw new DataServiceException(
                  string.Format("Error finding property {0}", propertyName),
                  exception);
            }
            return (pi);
        }

        private ITable GetTableForType(Type t)
        {
            ITable table = this.GetTable(t);

            if (table == null)
            {
                throw new DataServiceException(
                  string.Format("No table found for type {0}", t.Name));
            }
            return (table);
        }

        private static object Construct(Type t)
        {
            ConstructorInfo ci = t.GetConstructor(Type.EmptyTypes);

            if (ci == null)
            {
                throw new DataServiceException(
                  string.Format("No default ctor found for type {0}", t.Name));
            }
            return (ci.Invoke(null));
        }
        #endregion
    }
}
