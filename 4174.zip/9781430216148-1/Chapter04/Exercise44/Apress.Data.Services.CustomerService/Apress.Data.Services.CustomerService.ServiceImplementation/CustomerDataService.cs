﻿using System;
using System.Collections.Generic;
using System.Data.Services;
using System.Linq;
using System.ServiceModel.Web;
using Apress.Data.Services.CustomerService.Data.Linq;
using Apress.Data.Services.CustomerService.BusinessLogic;
using Apress.Data.Services.CustomerService.BusinessEntities;

namespace Apress.Data.Services.CustomerService.ServiceImplementation
{
    /// <summary>
    /// The customer data service implementation.
    /// </summary>
    public class CustomerDataService : DataService<CustomerDatabaseDataContext>
    {
        // This method is called only once to initialize service-wide policies.
        public static void InitializeService(IDataServiceConfiguration config)
        {
            config.SetEntitySetAccessRule("*", EntitySetRights.All);
            config.SetServiceOperationAccessRule("*", ServiceOperationRights.All);
        }

        [ChangeInterceptor("Customers")]
        public void OnCustomersChange(Customer c, UpdateOperations operations)
        {
            CustomerModel customer = new CustomerModel
            {
                Id = c.CustomerId,
                FirstName = c.FirstName,
                LastName = c.LastName,
                DateOfBirth = c.DateOfBirth,
                Gender = new GenderModel
                {
                    Id = c.GenderId
                },
                Salutation = new SalutationModel
                {
                    Id = c.SalutationId
                }
            };

            CustomerProcess process = new CustomerProcess();

            if (!process.IsPersistValid(customer))
            {
                string message = "Customer entity is not valid. Change operation failed";
                throw new DataServiceException(400, message);
            }
        }
    }
}
