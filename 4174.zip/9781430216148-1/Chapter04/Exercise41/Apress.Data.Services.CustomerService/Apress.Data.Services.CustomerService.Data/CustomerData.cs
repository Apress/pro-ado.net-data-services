﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using Apress.Data.Services.CustomerService.BusinessEntities;

namespace Apress.Data.Services.CustomerService.Data
{
    /// <summary>
    /// The customer data access layer.
    /// </summary>
    public class CustomerData : DataAccessBase
    {
        /// <summary>
        /// Gets the specified customer id.
        /// </summary>
        /// <param name="customerId">The customer id.</param>
        /// <returns></returns>
        public CustomerModel Get(int customerId)
        {
            CustomerModel customer = null;

            using (DataHelper dataHelper = new DataHelper(ConnectionStringName))
            {
                dataHelper.AddParameter("@CustomerId", ParameterDirection.Input, DbType.Int32, customerId);

                customer = EntityMapper.CreateCustomers(dataHelper.ExecuteDataReader("dbo.GetCustomerById")).FirstOrDefault();
            }

            return customer;
        }

        /// <summary>
        /// Gets the customers by lastname.
        /// </summary>
        /// <param name="lastname">The lastname.</param>
        /// <returns></returns>
        public List<CustomerModel> GetByLastname(string lastname)
        {
            List<CustomerModel> customers = new List<CustomerModel>();

            using (DataHelper dataHelper = new DataHelper(ConnectionStringName))
            {
                dataHelper.AddParameter("@Lastname", ParameterDirection.Input, DbType.String, lastname);

                customers = EntityMapper.CreateCustomers(dataHelper.ExecuteDataReader("dbo.GetCustomersByLastname"));
            }

            return customers;
        }

        /// <summary>
        /// Adds the specified customer.
        /// </summary>
        /// <param name="customer">The customer.</param>
        public void Add(CustomerModel customer)
        {
            using (DataHelper dataHelper = new DataHelper(ConnectionStringName))
            {
                dataHelper.AddParameter("@FirstName", ParameterDirection.Input, DbType.String, customer.FirstName);
                dataHelper.AddParameter("@LastName", ParameterDirection.Input, DbType.String, customer.LastName);
                dataHelper.AddParameter("@DateOfBirth", ParameterDirection.Input, DbType.DateTime, customer.DateOfBirth);
                dataHelper.AddParameter("@SalutationId", ParameterDirection.Input, DbType.Int32, customer.Salutation.Id);
                dataHelper.AddParameter("@GenderId", ParameterDirection.Input, DbType.String, customer.Gender.Id);
                dataHelper.AddParameter("@CustomerId", ParameterDirection.Output, DbType.Int32, null);

                dataHelper.ExecuteNonQuery("dbo.InsertCustomer");

                if (dataHelper.Parameters["@CustomerId"].Value != null)
                {
                    customer.Id = Convert.ToInt32(dataHelper.Parameters["@CustomerId"].Value);
                }
            }

            return;
        }

        /// <summary>
        /// Updates the specified customer.
        /// </summary>
        /// <param name="customer">The customer.</param>
        public void Update(CustomerModel customer)
        {
            using (DataHelper dataHelper = new DataHelper(ConnectionStringName))
            {
                dataHelper.AddParameter("@CustomerId", ParameterDirection.Input, DbType.Int32, customer.Id);
                dataHelper.AddParameter("@FirstName", ParameterDirection.Input, DbType.String, customer.FirstName);
                dataHelper.AddParameter("@LastName", ParameterDirection.Input, DbType.String, customer.LastName);
                dataHelper.AddParameter("@DateOfBirth", ParameterDirection.Input, DbType.DateTime, customer.DateOfBirth);
                dataHelper.AddParameter("@SalutationId", ParameterDirection.Input, DbType.Int32, customer.Salutation.Id);
                dataHelper.AddParameter("@GenderId", ParameterDirection.Input, DbType.String, customer.Gender.Id);

                dataHelper.ExecuteNonQuery("dbo.UpdateCustomer");
            }

            return;
        }
    }
}
