﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using Apress.Data.Services.CustomerService.BusinessEntities;

namespace Apress.Data.Services.CustomerService.Data
{
    /// <summary>
    /// Contains methods to map data readers returned from stored procedures to entities for use in the data access layer.
    /// </summary>
    internal static class EntityMapper
    {
        /// <summary>
        /// Creates the customer.
        /// </summary>
        /// <param name="dbDataReader">The db data reader.</param>
        /// <returns></returns>
        internal static List<CustomerModel> CreateCustomers(DbDataReader dbDataReader)
        {
            List<CustomerModel> customers = new List<CustomerModel>();

            if (dbDataReader != null && dbDataReader.HasRows)
            {
                while (dbDataReader.Read())
                {
                    CustomerModel customer = new CustomerModel
                    {
                        Id = dbDataReader.GetInt32(dbDataReader.GetOrdinal("CustomerId")),
                        FirstName = dbDataReader.GetString(dbDataReader.GetOrdinal("FirstName")),
                        LastName = dbDataReader.GetString(dbDataReader.GetOrdinal("LastName")),
                        DateOfBirth = dbDataReader.GetDateTime(dbDataReader.GetOrdinal("DateOfBirth")),
                        Gender = new GenderModel
                        {
                            Id = dbDataReader.GetString(dbDataReader.GetOrdinal("GenderId")),
                            Name = dbDataReader.GetString(dbDataReader.GetOrdinal("GenderName"))
                        },
                        Salutation = new SalutationModel
                        {
                            Id = dbDataReader.GetInt32(dbDataReader.GetOrdinal("SalutationId")),
                            Description = dbDataReader.GetString(dbDataReader.GetOrdinal("SalutationDescription"))
                        }
                    };

                    customers.Add(customer);
                }
            }

            return customers;
        }
    }
}
