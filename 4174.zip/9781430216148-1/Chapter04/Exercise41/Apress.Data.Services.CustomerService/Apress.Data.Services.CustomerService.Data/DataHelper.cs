﻿using System;
using System.Data;
using System.Data.Common;
using System.Configuration;

namespace Apress.Data.Services.CustomerService.Data
{
    /// <summary>Provides methods to simplify data access.</summary>
    public class DataHelper : IDisposable
    {
        #region Private Member Variables
        private DbCommand command;
        private DbConnection connection;
        private static DbProviderFactory factory;
        private ConnectionStringSettings connectionStringSettings;
        #endregion

        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="DataHelper"/> class.
        /// </summary>
        /// <param name="connectionStringName">Name of the connection string.</param>
        public DataHelper(string connectionStringName)
        {
            if (string.IsNullOrEmpty(connectionStringName))
                throw new ArgumentNullException("No connection string set in configuration file");

            connectionStringSettings = ConfigurationManager.ConnectionStrings[connectionStringName];
            connection = CreateConnection(connectionStringSettings);
            command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
        }
        #endregion

        #region Destructor
        /// <summary>Finalization code, that calls dispose to clean-up any unmanaged resources.</summary>
        ~DataHelper()
        {
            this.Dispose(false);
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets or sets the command timeout.
        /// </summary>
        /// <value>The command timeout.</value>
        public int CommandTimeout
        {
            get 
            {
                return Command.CommandTimeout; 
            }
            set 
            { 
                Command.CommandTimeout = value; 
            }
        }

        /// <summary>
        /// Gets the parameters.
        /// </summary>
        /// <value>The parameters.</value>
        public DbParameterCollection Parameters
        {
            get
            {
                return Command.Parameters;
            }
        }

        /// <summary>
        /// Gets the connection string settings.
        /// </summary>
        /// <value>The connection string settings.</value>
        public ConnectionStringSettings ConnectionStringSettings
        {
            get 
            { 
                return connectionStringSettings; 
            }
        }

        /// <summary>
        /// Gets the command.
        /// </summary>
        /// <value>The command.</value>
        public DbCommand Command
        {
            get 
            { 
                return command; 
            }
        }

        /// <summary>
        /// Gets the connection.
        /// </summary>
        /// <value>The connection.</value>
        public DbConnection Connection
        {
            get
            {
                return connection;
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Adds the parameter.
        /// </summary>
        /// <param name="parameterName">Name of the parameter.</param>
        /// <param name="direction">The direction.</param>
        /// <param name="type">The type.</param>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public DbParameter AddParameter(string parameterName, ParameterDirection direction, DbType type, object value)
        {
            return AddParameter(parameterName, direction, type, 0, value);
        }

        /// <summary>
        /// Adds the parameter.
        /// </summary>
        /// <param name="parameterName">Name of the parameter.</param>
        /// <param name="direction">The direction.</param>
        /// <param name="type">The type.</param>
        /// <param name="size">The size.</param>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public DbParameter AddParameter(string parameterName, ParameterDirection direction, DbType type, int size, object value)
        {
            DbParameter parameter = Command.CreateParameter();
            parameter.ParameterName = parameterName;
            parameter.Direction = direction;
            parameter.DbType = type;
            if (parameter.Direction != ParameterDirection.ReturnValue && parameter.Direction != ParameterDirection.Output)
            {
                parameter.Value = value;
            }

            if (size > 0)
            {
                parameter.Size = size;
            }

            Parameters.Add(parameter);

            return parameter;
        }

        /// <summary>
        /// Adds the parameter.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        public void AddParameter(DbParameter parameter)
        {
            Parameters.Add(parameter);
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="storedProcedure">The stored procedure.</param>
        /// <returns></returns>
        public int ExecuteNonQuery(string storedProcedure)
        {
            if (string.IsNullOrEmpty(storedProcedure))
            {
                throw new ArgumentNullException("Stored procedurte name cannot be null or empty.");
            }

            Command.CommandText = storedProcedure;
            if (Connection.State == ConnectionState.Closed)
            {
                Connection.Open();
            }

            // execute
            return Command.ExecuteNonQuery();
        }

        /// <summary>
        /// Executes the scalar.
        /// </summary>
        /// <param name="commandText">The command text.</param>
        /// <param name="isCommandText">if set to <c>true</c> [is command text].</param>
        /// <returns></returns>
        public object ExecuteScalar(string commandText, bool isCommandText)
        {
            if (string.IsNullOrEmpty(commandText))
            {
                throw new ArgumentNullException("Command text cannot be null or empty.");
            }
            Command.CommandType = CommandType.Text;
            Command.CommandText = commandText;
            if (Connection.State == ConnectionState.Closed)
            {
                Connection.Open();
            }

            // execute
            return Command.ExecuteScalar();
        }

        /// <summary>
        /// Executes the scalar.
        /// </summary>
        /// <param name="storedProcedure">The stored procedure.</param>
        /// <returns></returns>
        public object ExecuteScalar(string storedProcedure)
        {
            try
            {
                if (string.IsNullOrEmpty(storedProcedure))
                {
                    throw new ArgumentNullException("Stored procedure name cannot be null or empty.");
                }

                Command.CommandText = storedProcedure;
                if (Connection.State == ConnectionState.Closed)
                {
                    Connection.Open();
                }

                // execute
                return Command.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Executes the data reader.
        /// </summary>
        /// <param name="storedProcedure">The stored procedure.</param>
        /// <returns></returns>
        public DbDataReader ExecuteDataReader(string storedProcedure)
        {
            return ExecuteDataReader(storedProcedure, CommandBehavior.Default);
        }

        /// <summary>
        /// Executes the data reader.
        /// </summary>
        /// <param name="storedProcedure">The stored procedure.</param>
        /// <param name="behavior">The behavior.</param>
        /// <returns></returns>
        public DbDataReader ExecuteDataReader(string storedProcedure, CommandBehavior behavior)
        {
            try
            {
                if (string.IsNullOrEmpty(storedProcedure))
                {
                    throw new ArgumentNullException("Stored procedure name cannot be null or empty.");
                }

                Command.CommandText = storedProcedure;

                if (Connection.State == ConnectionState.Closed)
                {
                    Connection.Open();
                }

                // execute
                return Command.ExecuteReader(behavior);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Executes the data reader.
        /// </summary>
        /// <param name="commandText">The command text.</param>
        /// <param name="isCommandText">if set to <c>true</c> [is command text].</param>
        /// <returns></returns>
        public DbDataReader ExecuteDataReader(string commandText, bool isCommandText)
        {
            try
            {
                if (string.IsNullOrEmpty(commandText))
                {
                    throw new ArgumentNullException("Command text cannot be null or empty.");
                }

                //overrides the commandType to commandText
                Command.CommandType = CommandType.Text;

                Command.CommandText = commandText;

                if (Connection.State == ConnectionState.Closed)
                {
                    Connection.Open();
                }

                // execute
                return Command.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Creates the connection.
        /// </summary>
        /// <param name="connectionStringSettings">The connection string settings.</param>
        /// <returns></returns>
        private DbConnection CreateConnection(ConnectionStringSettings connectionStringSettings)
        {
            DataHelper.factory = DbProviderFactories.GetFactory(connectionStringSettings.ProviderName);
            DbConnection dbConnection = factory.CreateConnection();
            dbConnection.ConnectionString = connectionStringSettings.ConnectionString;

            return dbConnection;
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (connection.State != ConnectionState.Closed)
                    connection.Close();
            }
        }
        #endregion
    }
}