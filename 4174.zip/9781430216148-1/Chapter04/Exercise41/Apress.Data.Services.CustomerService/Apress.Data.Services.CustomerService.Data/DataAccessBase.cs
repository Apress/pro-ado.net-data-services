using System.Configuration;

namespace Apress.Data.Services.CustomerService.Data
{
	/// <summary>
	/// The base class for all Data Access Classes in the Data Access Layer 
	/// </summary>
	public abstract class DataAccessBase
	{
		#region Private Member Variables
		/// <summary>
		/// The name of the connection string that the Data access layer will use
		/// </summary>
		private string connectionStringName;
		#endregion

        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="DataAccessBase"/> class.
        /// </summary>
        public DataAccessBase()
        {
            connectionStringName = "CustomerDB";
        }
        #endregion

        #region Protected Properties
        /// <summary>
        /// Gets the connection string settings.
        /// </summary>
        /// <value>The connection string settings.</value>
        protected string ConnectionStringName
        {
            get
            {
                return connectionStringName;
            }
        }
        #endregion
	}
}
