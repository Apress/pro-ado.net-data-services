﻿using System;
using System.Runtime.Serialization;

namespace Apress.Data.Services.CustomerService.DataContracts
{
    /// <summary>
    /// The customer data contract
    /// </summary>
    [DataContract(Namespace = "http://schemas.apress.com/CustomerService")]
    public class Customer
    {
        /// <summary>
        /// Gets or sets the id.
        /// </summary>
        /// <value>The id.</value>
        [DataMember(Name="Id", Order=1)]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the salutation.
        /// </summary>
        /// <value>The salutation.</value>
        [DataMember(Name = "Salutation", Order=2)]
        public Salutation Salutation { get; set; }

        /// <summary>
        /// Gets or sets the first name.
        /// </summary>
        /// <value>The first name.</value>
        [DataMember(Name="FirstName", Order=3)]
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the last name.
        /// </summary>
        /// <value>The last name.</value>
        [DataMember(Name="LastName", Order=4)]
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets the date of birth.
        /// </summary>
        /// <value>The date of birth.</value>
        [DataMember(Name="DateOfBirth", Order=5)]
        public DateTime DateOfBirth { get; set; }

        /// <summary>
        /// Gets or sets the gender.
        /// </summary>
        /// <value>The gender.</value>
        [DataMember(Name="Gender", Order=6)]
        public Gender Gender { get; set; }

    }
}
