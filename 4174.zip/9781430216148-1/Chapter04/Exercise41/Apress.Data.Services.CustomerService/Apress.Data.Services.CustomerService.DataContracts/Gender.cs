﻿using System;
using System.Runtime.Serialization;

namespace Apress.Data.Services.CustomerService.DataContracts
{
    /// <summary>
    /// The gender data contract
    /// </summary>
    [DataContract(Namespace = "http://schemas.apress.com/CustomerService")]
    public class Gender
    {
        /// <summary>
        /// Gets or sets the id.
        /// </summary>
        /// <value>The id.</value>
        [DataMember(Name = "Id", Order = 1)]
        public string Id { get; set; }
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [DataMember(Name = "Name", Order = 2)]
        public string Name { get; set; }
    }
}
