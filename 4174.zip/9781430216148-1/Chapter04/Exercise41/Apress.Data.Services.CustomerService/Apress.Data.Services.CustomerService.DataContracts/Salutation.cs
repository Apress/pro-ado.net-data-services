﻿using System;
using System.Runtime.Serialization;

namespace Apress.Data.Services.CustomerService.DataContracts
{
    /// <summary>
    /// The salutation data contract
    /// </summary>
    [DataContract(Namespace = "http://schemas.apress.com/CustomerService")]
    public class Salutation
    {
        /// <summary>
        /// Gets or sets the id.
        /// </summary>
        /// <value>The id.</value>
        [DataMember(Name = "Id", Order = 1)]
        public int Id { get; set; }
        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        [DataMember(Name = "Description", Order = 2)]
        public string Description { get; set; }
    }
}
