﻿using System.Runtime.Serialization;

namespace Apress.Data.Services.CustomerService.FaultContracts
{
    [DataContract(Namespace = "http://schemas.apress.com/CustomerService")]
    public class GeneralError
    {
        [DataMember]
        public string Message { get; set; }
    }
}
