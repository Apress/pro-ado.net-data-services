﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Apress.Data.Services.CustomerService.DataContracts;
using Apress.Data.Services.CustomerService.FaultContracts;

namespace Apress.Data.Services.CustomerService.ServiceContracts
{
    [ServiceContract(Namespace="http://schemas.apress.com/CustomerService")]
    public interface ICustomerManagement
    {
        /// <summary>
        /// Persists the customer.
        /// </summary>
        /// <param name="customer">The customer.</param>
        [OperationContract]
        [FaultContract(typeof(GeneralError))]
        [FaultContract(typeof(ValidationError))]
        int PersistCustomer(Customer customer);

        /// <summary>
        /// Gets the customer by id.
        /// </summary>
        /// <param name="customerId">The customer id.</param>
        /// <returns></returns>
        [OperationContract]
        [FaultContract(typeof(GeneralError))]
        Customer GetCustomerById(int customerId);

        /// <summary>
        /// Gets the customers by lastname.
        /// </summary>
        /// <param name="lastname">The lastname.</param>
        /// <returns></returns>
        [OperationContract]
        [FaultContract(typeof(GeneralError))]
        Customer[] GetCustomersByLastname(string lastname);
    }
}
