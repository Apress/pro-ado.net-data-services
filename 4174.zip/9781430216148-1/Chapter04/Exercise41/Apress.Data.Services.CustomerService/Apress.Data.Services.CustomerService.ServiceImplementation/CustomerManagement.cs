﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using Apress.Data.Services.CustomerService.BusinessEntities;
using Apress.Data.Services.CustomerService.BusinessLogic;
using Apress.Data.Services.CustomerService.DataContracts;
using Apress.Data.Services.CustomerService.FaultContracts;
using Apress.Data.Services.CustomerService.ServiceContracts;

namespace Apress.Data.Services.CustomerService.ServiceImplementation
{
    /// <summary>
    /// The service implementation of the customer management service.
    /// </summary>
    [ServiceBehavior(Namespace="http://schemas.apress.com/CustomerService")]
    public class CustomerManagement : ICustomerManagement
    {
        private CustomerProcess customerProcess;

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerManagement"/> class.
        /// </summary>
        public CustomerManagement ()
	    {
            customerProcess = new CustomerProcess();
	    }

        #region ICustomerManagement Members

        /// <summary>
        /// Persists the customer.
        /// </summary>
        /// <param name="customer">The customer.</param>
        public int PersistCustomer(Customer customer)
        {
            if (customer == null || customer.Gender == null || customer.Salutation == null)
            {
                return 0;
            }

            try
            {
                CustomerModel c = new CustomerModel
                {
                    Id = customer.Id,
                    FirstName = customer.FirstName,
                    LastName = customer.LastName,
                    DateOfBirth = customer.DateOfBirth,
                    Gender = new GenderModel
                    {
                        Id = customer.Gender.Id,
                        Name = customer.Gender.Name
                    },
                    Salutation = new SalutationModel
                    {
                        Id = customer.Salutation.Id,
                        Description = customer.Salutation.Description
                    }
                };
                customerProcess.Persist(c);

                return c.Id;
            }
            catch (CustomerValidationException ex)
            {
                ValidationError fault = new ValidationError { Message = ex.Message };
                throw new FaultException<ValidationError>(fault, new FaultReason("PersistCustomer failed validation"));

            }
            catch (Exception ex)
            {
                GeneralError fault = new GeneralError { Message = ex.Message };
                throw new FaultException<GeneralError>(fault, new FaultReason("PersistCustomer failed with a general fault"));
            }
        }

        /// <summary>
        /// Gets the customer by id.
        /// </summary>
        /// <param name="customerId">The customer id.</param>
        /// <returns></returns>
        public Customer GetCustomerById(int customerId)
        {
            Customer customer = null;

            try 
	        {
                CustomerModel c = customerProcess.Get(customerId);
                customer = new Customer
                {
                    Id = c.Id,
                    FirstName = c.FirstName,
                    LastName = c.LastName,
                    DateOfBirth = c.DateOfBirth,
                    Gender = new Gender
                    {
                        Id = c.Gender.Id,
                        Name = c.Gender.Name
                    },
                    Salutation = new Salutation
                    {
                        Id = c.Salutation.Id,
                        Description = c.Salutation.Description
                    }
                };
	        }
	        catch (Exception)
	        {
                GeneralError fault = new GeneralError{Message = "Error Getting Customer"};
		        throw new FaultException<GeneralError>(fault, new FaultReason("GetCustomerById failed with a general fault"));
	        }

            return customer;
        }

        /// <summary>
        /// Gets the customers by lastname.
        /// </summary>
        /// <param name="lastname">The lastname.</param>
        /// <returns></returns>
        public Customer[] GetCustomersByLastname(string lastname)
        {
            Customer[] customers = null;

            try
            {
                List<CustomerModel> customerModels = customerProcess.GetByLastName(lastname);

                customers = (from c in customerModels
                            select new Customer
                            {
                                Id = c.Id,
                                FirstName = c.FirstName,
                                LastName = c.LastName,
                                DateOfBirth = c.DateOfBirth,
                                Gender = new Gender
                                {
                                    Id = c.Gender.Id,
                                    Name = c.Gender.Name
                                },
                                Salutation = new Salutation
                                {
                                    Id = c.Salutation.Id,
                                    Description = c.Salutation.Description
                                }
                            }).ToArray();
            }
            catch (Exception)
            {
                GeneralError fault = new GeneralError { Message = "Error Getting Customers by last name" };
                throw new FaultException<GeneralError>(fault, new FaultReason("GetCustomerByLastname failed with a general fault"));
            }

            return customers;
        }

        #endregion

    }
}
