﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using Apress.Data.Services.CustomerService.BusinessEntities;
using Apress.Data.Services.CustomerService.Data.Linq;

namespace Apress.Data.Services.CustomerService.Data
{
    /// <summary>
    /// The customer data access layer.
    /// </summary>
    public class CustomerData
    {
        private CustomerDatabaseDataContext database;

        public CustomerData()
        {
            database = new CustomerDatabaseDataContext();
        }

        /// <summary>
        /// Gets the specified customer id.
        /// </summary>
        /// <param name="customerId">The customer id.</param>
        /// <returns></returns>
        public CustomerModel Get(int customerId)
        {
            CustomerModel customer = (from c in database.Customers
                           where c.CustomerId == customerId
                           select new CustomerModel
                           {
                               Id = c.CustomerId,
                               FirstName = c.FirstName,
                               LastName = c.LastName,
                               DateOfBirth = c.DateOfBirth,
                               Gender = new GenderModel
                               {
                                   Id = c.Gender.GenderId.ToString(),
                                   Name = c.Gender.GenderName
                               },
                               Salutation = new SalutationModel
                               {
                                   Id = c.Salutation.SalutationId,
                                   Description = c.Salutation.SalutationDescription
                               }
                           }).FirstOrDefault();

            return customer;
        }

        /// <summary>
        /// Gets the customers by lastname.
        /// </summary>
        /// <param name="lastname">The lastname.</param>
        /// <returns></returns>
        public List<CustomerModel> GetByLastname(string lastname)
        {
            List<CustomerModel> customers = (from c in database.Customers
                                             where c.LastName.Contains(lastname)
                                             select new CustomerModel
                                             {
                                                 Id = c.CustomerId,
                                                 FirstName = c.FirstName,
                                                 LastName = c.LastName,
                                                 DateOfBirth = c.DateOfBirth,
                                                 Gender = new GenderModel
                                                 {
                                                     Id = c.Gender.GenderId.ToString(),
                                                     Name = c.Gender.GenderName
                                                 },
                                                 Salutation = new SalutationModel
                                                 {
                                                     Id = c.Salutation.SalutationId,
                                                     Description = c.Salutation.SalutationDescription
                                                 }
                                             }).ToList();

            return customers;
        }

        /// <summary>
        /// Adds the specified customer.
        /// </summary>
        /// <param name="customer">The customer.</param>
        public void Add(CustomerModel customer)
        {
            Customer c = new Customer
            {
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                DateOfBirth = customer.DateOfBirth,
                GenderId = Convert.ToChar(customer.Gender.Id),
                SalutationId = customer.Salutation.Id
            };

            database.Customers.InsertOnSubmit(c);
            database.SubmitChanges();

            customer.Id = c.CustomerId;
        }

        /// <summary>
        /// Updates the specified customer.
        /// </summary>
        /// <param name="customer">The customer.</param>
        public void Update(CustomerModel customer)
        {
            Customer c = database.Customers.Where(cust => customer.Id == cust.CustomerId).FirstOrDefault();

            if (c != null)
            {
                c.FirstName = customer.FirstName;
                c.LastName = customer.LastName;
                c.DateOfBirth = customer.DateOfBirth;
                c.GenderId = Convert.ToChar(customer.Gender.Id);
                c.SalutationId = customer.Salutation.Id;
            }

            database.SubmitChanges();
        }
    }
}
