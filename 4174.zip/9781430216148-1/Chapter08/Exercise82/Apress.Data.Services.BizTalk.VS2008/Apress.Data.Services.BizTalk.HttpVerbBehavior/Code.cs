﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Description;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;
using System.ServiceModel;
using System.ServiceModel.Configuration;
using System.Configuration;
using System.Net;

namespace Apress.Data.Services.BizTalk.HttpVerbBehavior
{
    public class VerbMessageInspector : IClientMessageInspector
    {
        public VerbMessageInspector(string verb, string contentType)
        {
            this._verb = verb;
            this._contentType = contentType;
        }
        string _verb;
        string _contentType;

        public void AfterReceiveReply(ref System.ServiceModel.Channels.Message reply, object correlationState)
        {


        }
        public object BeforeSendRequest(ref
            System.ServiceModel.Channels.Message request,
            IClientChannel channel)
        {

            //Get the HTTP Request Message Property from the request
            HttpRequestMessageProperty mp = null;
            if (request.Properties.ContainsKey(HttpRequestMessageProperty.Name))
                mp = (HttpRequestMessageProperty)request.Properties[HttpRequestMessageProperty.Name];
            else
            {
                mp = new HttpRequestMessageProperty();
                request.Properties.Add(HttpRequestMessageProperty.Name, mp);
            }

            mp.Method = this._verb;

            //Set the contentType to default ATOM format
            if (String.IsNullOrEmpty(this._contentType))
            {
                this._contentType = "application/atom+xml";
            }

            //Set the Content Type
            mp = (HttpRequestMessageProperty)request.Properties[HttpRequestMessageProperty.Name];
            mp.Headers.Add(HttpResponseHeader.ContentType, _contentType);

            //If the method is GET then supress the entity body
            if (mp.Method == "GET")
            {
                mp.SuppressEntityBody = true;
                Message msg =
                    Message.CreateMessage(MessageVersion.None, "*");
                msg.Properties.Add(HttpRequestMessageProperty.Name, mp);
                request = msg;

            }

            return null;

        }


    }
    public class HttpVerbBehavior : IEndpointBehavior
    {
        public HttpVerbBehavior(string verb, string contentType)
        {
            this._verb = verb;
            this._contentType = contentType;
        }
        string _verb;
        string _contentType;

        #region IEndpointBehavior Members

        public void AddBindingParameters(ServiceEndpoint endpoint, System.ServiceModel.Channels.BindingParameterCollection bindingParameters)
        {
        }

        public void ApplyClientBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.ClientRuntime clientRuntime)
        {
            clientRuntime.MessageInspectors.Add(new VerbMessageInspector(this._verb, this._contentType));
        }

        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.EndpointDispatcher endpointDispatcher)
        {
        }

        public void Validate(ServiceEndpoint endpoint)
        {
        }

        #endregion
    }
    public class HttpVerbElement : BehaviorExtensionElement
    {
        public override Type BehaviorType
        {
            get { return typeof(HttpVerbBehavior); }
        }

        protected override object CreateBehavior()
        {
            return new HttpVerbBehavior(this.Verb, this.ContentType);
        }

        ConfigurationPropertyCollection _properties;


        [ConfigurationProperty("verb")]
        public string Verb
        {
            get { return (string)base["verb"]; }
            set { base["verb"] = value; }
        }

        [ConfigurationProperty("contentType")]
        public string ContentType
        {
            get { return (string)base["contentType"]; }
            set { base["contentType"] = value; }
        }

        protected override ConfigurationPropertyCollection Properties
        {
            get
            {
                if (this._properties == null)
                {
                    ConfigurationPropertyCollection configProperties = new ConfigurationPropertyCollection();
                    configProperties.Add(new ConfigurationProperty("verb", typeof(string), null, null, null, ConfigurationPropertyOptions.None));
                    configProperties.Add(new ConfigurationProperty("contentType", typeof(string), null, null, null, ConfigurationPropertyOptions.None));
                    this._properties = configProperties;
                }
                return this._properties;
            }
        }


    }
}
