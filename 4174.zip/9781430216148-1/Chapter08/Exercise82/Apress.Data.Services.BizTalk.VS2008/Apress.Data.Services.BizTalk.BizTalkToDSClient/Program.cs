﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;

namespace BizTalkClient
{
    class BizTalkClient
    {
        static void Main(string[] args)
        {
            NetTcpBinding b = new NetTcpBinding();
            EndpointAddress ea =
                new EndpointAddress("net.tcp://localhost/BizTalkToDataServices");
            ChannelFactory<IBTSGeneric> cf =
                new ChannelFactory<IBTSGeneric>(b, ea);
            cf.Open();
            IBTSGeneric c = cf.CreateChannel();
            Message msgToSend =
                Message.CreateMessage(MessageVersion.Default,
                "*",
                "Test Message  - will get stripped");
            Message responseMsg = c.Get(msgToSend);
            XmlReader xr = responseMsg.GetReaderAtBodyContents();
            xr.MoveToContent();
            Console.WriteLine(xr.ReadOuterXml());
            cf.Close();


            Console.Read();

        }
    }
    [ServiceContract]
    public interface IBTSGeneric
    {
        [OperationContract(Action = "*", ReplyAction = "*")]
        Message Get(Message msg);
    }
}
