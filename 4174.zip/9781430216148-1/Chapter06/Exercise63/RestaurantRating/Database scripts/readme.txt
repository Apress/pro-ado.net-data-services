Either run SQLDDL + SQLCreateScript or

Navigate to SQL Server explorer, Right click Databases -> attach -> Navigate to ApressRestaurantRating.mdf -> Rename to ApressRestaurantRating -> Grant DBO Security access to local administrator.