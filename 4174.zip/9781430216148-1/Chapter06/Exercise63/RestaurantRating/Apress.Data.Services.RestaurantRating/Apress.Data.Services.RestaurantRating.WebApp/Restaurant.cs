﻿using System;
using System.Data;

namespace Apress.Data.Services.RestaurantRating.WebApp
{

    public partial class Restaurant :
                      global::System.Data.Objects.DataClasses.EntityObject
    {
        //[global::System.Data.Objects.DataClasses.EdmScalarPropertyAttribute(IsNullable = false)]
        [global::System.Runtime.Serialization.DataMemberAttribute()]
        public int Rating
        {
            get 
            {

                return Convert.ToInt32((this.Food + this.Decor + this.Service) / 3);
            }
        }
    }
}

