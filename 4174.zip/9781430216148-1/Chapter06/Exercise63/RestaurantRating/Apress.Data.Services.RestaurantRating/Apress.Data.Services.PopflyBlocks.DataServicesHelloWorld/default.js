// This is some sample JavaScript code.  Change it for your block.

function ApressHelloWorldClass()
{
}

ApressHelloWorldClass.prototype.hello = function(firstName, lastName) {
     
    var helloWorldResult = new HelloWorldObject(firstName, lastName);
    return helloWorldResult;
};

HelloWorldObject.prototype.toString = function() {
    var html = "<div>";
    html += "<strong> My favorite beatle is " + this.FirstName + " " + this.LastName + "</strong>"
    html += "</div>";
    return html;
};

function HelloWorldObject(firstName, lastName) 
{
     this.FirstName=firstName;
     this.LastName=lastName;
}