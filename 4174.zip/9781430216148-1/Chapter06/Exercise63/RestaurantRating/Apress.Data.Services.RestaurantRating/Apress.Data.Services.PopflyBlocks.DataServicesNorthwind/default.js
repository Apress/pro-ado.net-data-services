/// -----------------------------------------------------------------------------------------------
/// Do not remove these references. They are used by Popfly to provide intellisense in your editor.
///
/// For Popfly Block development documentation, please see http://go.microsoft.com/fwlink/?LinkId=106942
/// 
/// <reference name="MicrosoftAjax.js" assembly="System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35" />
/// <reference name="Microsoft.Popfly.Explorer.Wizard.BlockAPI.js" assembly="Microsoft.Popfly.Explorer.Wizard, Version=1.0.0.0, Culture=neutral, PublicKeyToken=c1ceb53b217f2480" />
/// -----------------------------------------------------------------------------------------------


//declare/define the class
function NorthwindClass() {
}

//define the getCustomers function in the class
NorthwindClass.prototype.getNorthwindCustomersByCity= function(CityName) {

    
    var jsonText = environment.getHttpResponse("http://dataservices.spheregen.com/Northwind/Northwind.svc/Customers?$filter=(City eq '" + CityName + "')",	null, [{ "Key": "Accept", "Value": "application/json"}], null);

    var response = (eval("(" + jsonText.responseText + ")")).d;
    var results = []
    var currentResult = {}
    for (var i in response) 
    {
        currentResult = new Customer(response[i]["CustomerID"],
                                     response[i]["CompanyName"]);
        results.push(currentResult);
    }

    return results;
}

Customer.prototype.toString = function() {
    var html = "<div>";
    html += "<strong>" + this.CompanyName + "</strong>"
    html += "</div>";
    return html;
};


//define the customer object that will be returned
function Customer(customerId, companyName) {
    this.CustomerID= customerId;
    this.CompanyName= companyName;
}

// **************