﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Data.Services.Client;
using CustomerModel;

namespace Apress.Data.Services.CustomerService.SilverlightClient
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the Click event of the SearchButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.RoutedEventArgs"/> instance containing the event data.</param>
        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            // get the text from the search text box
            string searchText = SearchTextBox.Text;

            ExecuteSearch(searchText);
        }

        /// <summary>
        /// Executes the search.
        /// </summary>
        /// <param name="searchText">The search text.</param>
        private void ExecuteSearch(string searchText)
        {
            // create client proxy
            CustomerEntities dataService = new CustomerEntities(new Uri("CustomerDataService.svc", UriKind.Relative));

            // query data service using LINQ
            var customers = from c in dataService.Customers.Expand("Salutation").Expand("Gender")
                            where c.LastName.Contains(searchText)
                            select c;

            DataServiceQuery<Customer> customerQuery = (DataServiceQuery<Customer>)customers;

            // execute the query asynchronously
            customerQuery.BeginExecute(new AsyncCallback(OnSearchComplete), customerQuery);
        }

        /// <summary>
        /// Called when [search complete].
        /// </summary>
        /// <param name="result">The result.</param>
        void OnSearchComplete(IAsyncResult result)
        {
            // Get a reference to the Query
            DataServiceQuery<Customer> customerQuery =
              (DataServiceQuery<Customer>)result.AsyncState;

            // assign results to customers collection.
            Customers = customerQuery.EndExecute(result).ToList();
        }

        /// <summary>
        /// Gets or sets the customers.
        /// </summary>
        /// <value>The customers.</value>
        public List<Customer> Customers
        {
            get
            {
                return (List<Customer>)CustomersDataGrid.DataContext;
            }
            set
            {
                CustomersDataGrid.DataContext = value;
            }
        }

    }
}
